# class group of odd order
sage trees_generation.sage -7 -23 -31 > example_01_trees.log
sage testrelations.sage > example_01_rels.log
sage cl_dlog.sage > example_01_dlog.log