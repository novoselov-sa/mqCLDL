cd ..
make

sage trees_generation.sage 5 13 17 29 37 41 --gm-add=100 --no-hard > experiments/d64_re_gm_add_100_no_hard_trees.log 2>&1
sage testrelations.sage > experiments/d64_re_gm_add_100_no_hard_rels.log 2>&1
zip -9 -r experiments/d64_re_gm_add_100_no_hard_trees_rels.zip trees relations experiments/d64_re_gm_add_100_no_hard_rels.log experiments/d64_re_gm_add_100_no_hard_trees.log

#sage trees_generation.sage 5 13 17 29 37 41 53 --gm-add=200 --no-hard > experiments/d128_re_gm_add_200_no_hard_trees.log 2>&1
#sage testrelations.sage > experiments/d128_re_gm_add_200_no_hard_rels.log 2>&1
#zip -9 -r experiments/d128_re_gm_add_200_no_hard_trees_rels.zip trees relations experiments/d128_re_gm_add_200_no_hard_rels.log experiments/d128_re_gm_add_200_no_hard_trees.log

# sage trees_generation.sage 5 13 17 29 37 41 53 --gm-add=200 --no-hard > experiments/d128_re_gm_add_200_no_hard_trees.log 2>&1
# sage testrelations.sage > experiments/d128_re_gm_add_200_no_hard_rels.log 2>&1
# zip -9 -r experiments/d128_re_gm_add_200_no_hard_trees_rels.zip trees relations experiments/d128_re_gm_add_200_no_hard_rels.log experiments/d128_re_gm_add_200_no_hard_trees.log


# sage trees_generation.sage 5 13 17 29 37 41 53 61 --gm-add=200 --no-hard > experiments/d256_re_gm_add_200_no_hard_trees.log 2>&1
# sage testrelations.sage > experiments/d256_re_gm_add_200_no_hard_rels.log 2>&1
# zip -9 -r experiments/d256_re_gm_add_200_no_hard_trees_rels.zip trees relations experiments/d256_re_gm_add_200_no_hard_rels.log experiments/d256_re_gm_add_200_no_hard_trees.log


# sage trees_generation.sage 5 13 17 29 37 41 53 61 --gm-add=250 --no-hard > experiments/d256_re_gm_add_250_no_hard_trees.log 2>&1
# sage testrelations.sage > experiments/d256_re_gm_add_250_no_hard_rels.log 2>&1
# zip -9 -r experiments/d256_re_gm_add_250_no_hard_trees_rels.zip trees relations experiments/d256_re_gm_add_250_no_hard_rels.log experiments/d256_re_gm_add_250_no_hard_trees.log


# sage trees_generation.sage 5 13 17 29 37 41 53 61 --gm-add=300 --no-hard > experiments/d256_re_gm_add_300_no_hard_trees.log 2>&1
# sage testrelations.sage > experiments/d256_re_gm_add_300_no_hard_rels.log 2>&1
# zip -9 -r experiments/d256_re_gm_add_300_no_hard_trees_rels.zip trees relations experiments/d256_re_gm_add_300_no_hard_rels.log experiments/d256_re_gm_add_300_no_hard_trees.log


# sage trees_generation.sage 5 13 17 29 37 41 53 61 --gm-add=350 --no-hard > experiments/d256_re_gm_add_350_no_hard_trees.log 2>&1
# sage testrelations.sage > experiments/d256_re_gm_add_350_no_hard_rels.log 2>&1
# zip -9 -r experiments/d256_re_gm_add_350_no_hard_trees_rels.zip trees relations experiments/d256_re_gm_add_350_no_hard_rels.log experiments/d256_re_gm_add_350_no_hard_trees.log


# sage trees_generation.sage 5 13 17 29 37 41 53 61 --gm-add=400 --no-hard > experiments/d256_re_gm_add_400_no_hard_trees.log 2>&1
# sage testrelations.sage > experiments/d256_re_gm_add_400_no_hard_rels.log 2>&1
# zip -9 -r experiments/d256_re_gm_add_400_no_hard_trees_rels.zip trees relations experiments/d256_re_gm_add_400_no_hard_rels.log experiments/d256_re_gm_add_400_no_hard_trees.log


# sage trees_generation.sage 5 13 17 29 37 41 53 61 --gm-add=450 --no-hard > experiments/d256_re_gm_add_450_no_hard_trees.log 2>&1
# sage testrelations.sage > experiments/d256_re_gm_add_450_no_hard_rels.log 2>&1
# zip -9 -r experiments/d256_re_gm_add_450_no_hard_trees_rels.zip trees relations experiments/d256_re_gm_add_450_no_hard_rels.log experiments/d256_re_gm_add_450_no_hard_trees.log
