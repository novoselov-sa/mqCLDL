# class group of even order
# food = {'a': 5, 'b': 79, 'c': 89}
sage trees_generation.sage 5 79 89 > example_02_trees.log
sage testrelations.sage > example_02_rels.log
sage cl_dlog.sage > example_02_dlog.log